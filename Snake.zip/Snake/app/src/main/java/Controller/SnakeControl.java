package Controller;

public class SnakeControl {
        
}
